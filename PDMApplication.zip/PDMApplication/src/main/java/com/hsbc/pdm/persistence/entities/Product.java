package com.hsbc.pdm.persistence.entities;

import java.util.Set;

import org.springframework.data.annotation.Id;

/**
 * @author kalakuriphani
 * @version 1.0
 * @created 10-Oct-2016 02:06:16
 */
public class Product {

	private AccessChannels accessChannlels;
	private Availability availability;
	private Charges charges;
	private Company companyId;
	private CreditProduct creditProduct;
	private Currency currency;
	private CurrentAccount currentAccount;
	private String description;
	private Eligibility eligibility;
	private Set<Features> features;
	@Id
	private int id;
	private InterestRate interestRate;
	private String name;
	private OverDraft overDraft;
	private SavingsProduct savingsProduct;
	private ProductSegment segment;
	private String TermsandConditions;
	private ProductType type;
	private String url;
	public Currency m_Currency;
	public AccessChannels m_AccessChannels;
	public Company m_Company;
	public InterestRate m_InterestRate;
	public CreditProduct m_CreditProduct;
	public Availability m_Availability;
	public Charges m_Charges;
	public Eligibility m_Eligibility;
	public SavingsProduct m_SavingsProduct;
	public OverDraft m_OverDraft;
	public Features m_Features;
	public CurrentAccount m_CurrentAccount;

	public Product(){

	}

	public void finalize() throws Throwable {

	}

	public AccessChannels getAccessChannlels() {
		return accessChannlels;
	}

	public void setAccessChannlels(AccessChannels accessChannlels) {
		this.accessChannlels = accessChannlels;
	}

	public Availability getAvailability() {
		return availability;
	}

	public void setAvailability(Availability availability) {
		this.availability = availability;
	}

	public Charges getCharges() {
		return charges;
	}

	public void setCharges(Charges charges) {
		this.charges = charges;
	}

	public Company getCompanyId() {
		return companyId;
	}

	public void setCompanyId(Company companyId) {
		this.companyId = companyId;
	}

	public CreditProduct getCreditProduct() {
		return creditProduct;
	}

	public void setCreditProduct(CreditProduct creditProduct) {
		this.creditProduct = creditProduct;
	}

	public Currency getCurrency() {
		return currency;
	}

	public void setCurrency(Currency currency) {
		this.currency = currency;
	}

	public CurrentAccount getCurrentAccount() {
		return currentAccount;
	}

	public void setCurrentAccount(CurrentAccount currentAccount) {
		this.currentAccount = currentAccount;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Eligibility getEligibility() {
		return eligibility;
	}

	public void setEligibility(Eligibility eligibility) {
		this.eligibility = eligibility;
	}

	public Set<Features> getFeatures() {
		return features;
	}

	public void setFeatures(Set<Features> features) {
		this.features = features;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public InterestRate getInterestRate() {
		return interestRate;
	}

	public void setInterestRate(InterestRate interestRate) {
		this.interestRate = interestRate;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public OverDraft getOverDraft() {
		return overDraft;
	}

	public void setOverDraft(OverDraft overDraft) {
		this.overDraft = overDraft;
	}

	public SavingsProduct getSavingsProduct() {
		return savingsProduct;
	}

	public void setSavingsProduct(SavingsProduct savingsProduct) {
		this.savingsProduct = savingsProduct;
	}

	public ProductSegment getSegment() {
		return segment;
	}

	public void setSegment(ProductSegment segment) {
		this.segment = segment;
	}

	public String getTermsandConditions() {
		return TermsandConditions;
	}

	public void setTermsandConditions(String termsandConditions) {
		TermsandConditions = termsandConditions;
	}

	public ProductType getType() {
		return type;
	}

	public void setType(ProductType type) {
		this.type = type;
	}

	public String getUrl() {
		return url;
	}

	public void setUrl(String url) {
		this.url = url;
	}

	public Currency getM_Currency() {
		return m_Currency;
	}

	public void setM_Currency(Currency m_Currency) {
		this.m_Currency = m_Currency;
	}

	public AccessChannels getM_AccessChannels() {
		return m_AccessChannels;
	}

	public void setM_AccessChannels(AccessChannels m_AccessChannels) {
		this.m_AccessChannels = m_AccessChannels;
	}

	public Company getM_Company() {
		return m_Company;
	}

	public void setM_Company(Company m_Company) {
		this.m_Company = m_Company;
	}

	public InterestRate getM_InterestRate() {
		return m_InterestRate;
	}

	public void setM_InterestRate(InterestRate m_InterestRate) {
		this.m_InterestRate = m_InterestRate;
	}

	public CreditProduct getM_CreditProduct() {
		return m_CreditProduct;
	}

	public void setM_CreditProduct(CreditProduct m_CreditProduct) {
		this.m_CreditProduct = m_CreditProduct;
	}

	public Availability getM_Availability() {
		return m_Availability;
	}

	public void setM_Availability(Availability m_Availability) {
		this.m_Availability = m_Availability;
	}

	public Charges getM_Charges() {
		return m_Charges;
	}

	public void setM_Charges(Charges m_Charges) {
		this.m_Charges = m_Charges;
	}

	public Eligibility getM_Eligibility() {
		return m_Eligibility;
	}

	public void setM_Eligibility(Eligibility m_Eligibility) {
		this.m_Eligibility = m_Eligibility;
	}

	public SavingsProduct getM_SavingsProduct() {
		return m_SavingsProduct;
	}

	public void setM_SavingsProduct(SavingsProduct m_SavingsProduct) {
		this.m_SavingsProduct = m_SavingsProduct;
	}

	public OverDraft getM_OverDraft() {
		return m_OverDraft;
	}

	public void setM_OverDraft(OverDraft m_OverDraft) {
		this.m_OverDraft = m_OverDraft;
	}

	public Features getM_Features() {
		return m_Features;
	}

	public void setM_Features(Features m_Features) {
		this.m_Features = m_Features;
	}

	public CurrentAccount getM_CurrentAccount() {
		return m_CurrentAccount;
	}

	public void setM_CurrentAccount(CurrentAccount m_CurrentAccount) {
		this.m_CurrentAccount = m_CurrentAccount;
	}

}