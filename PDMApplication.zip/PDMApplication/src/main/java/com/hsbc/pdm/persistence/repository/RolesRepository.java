package com.hsbc.pdm.persistence.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.hsbc.pdm.persistence.entities.Roles;

/**
 * @author kalakuriphani
 * @version 1.0
 * @created 10-Oct-2016 02:35:24
 */
public interface RolesRepository extends MongoRepository<Roles,Integer> {

	

}