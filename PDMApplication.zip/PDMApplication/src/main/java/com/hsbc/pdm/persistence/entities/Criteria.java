package com.hsbc.pdm.persistence.entities;


/**
 * @author kalakuriphani
 * @version 1.0
 * @created 10-Oct-2016 02:06:38
 */
public class Criteria {

	public Criteria(){

	}

	public void finalize() throws Throwable {

	}

}