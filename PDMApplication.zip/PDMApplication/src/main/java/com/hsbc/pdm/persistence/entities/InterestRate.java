package com.hsbc.pdm.persistence.entities;

import org.springframework.data.annotation.Id;

/**
 * @author kalakuriphani
 * @version 1.0
 * @created 10-Oct-2016 02:06:29
 */
public class InterestRate {

	@Id
	private int id;
	private String interestRateTier;
	private String notes;
	private String rate;

	public InterestRate(){

	}

	public void finalize() throws Throwable {

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getInterestRateTier() {
		return interestRateTier;
	}

	public void setInterestRateTier(String interestRateTier) {
		this.interestRateTier = interestRateTier;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

	public String getRate() {
		return rate;
	}

	public void setRate(String rate) {
		this.rate = rate;
	}

}