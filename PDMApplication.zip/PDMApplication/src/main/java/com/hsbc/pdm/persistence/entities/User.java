package com.hsbc.pdm.persistence.entities;

import java.util.Set;

import org.springframework.data.annotation.Id;

/**
 * @author kalakuriphani
 * @version 1.0
 * @created 10-Oct-2016 02:06:33
 */
public class User {

	private Set<Access> access;
	private String firstName;
	@Id
	private int id;
	private String lastName;
	private Roles role;
	private String staffId;
	public Roles m_Roles;

	public User(){

	}

	public void finalize() throws Throwable {

	}

	public Set<Access> getAccess() {
		return access;
	}

	public void setAccess(Set<Access> access) {
		this.access = access;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public Roles getRole() {
		return role;
	}

	public void setRole(Roles role) {
		this.role = role;
	}

	public String getStaffId() {
		return staffId;
	}

	public void setStaffId(String staffId) {
		this.staffId = staffId;
	}

	public Roles getM_Roles() {
		return m_Roles;
	}

	public void setM_Roles(Roles m_Roles) {
		this.m_Roles = m_Roles;
	}

}