package com.hsbc.pdm.persistence.entities;


/**
 * @author kalakuriphani
 * @version 1.0
 * @created 10-Oct-2016 02:06:19
 */
public class Company {

	public Company(){

	}

	public void finalize() throws Throwable {

	}

}