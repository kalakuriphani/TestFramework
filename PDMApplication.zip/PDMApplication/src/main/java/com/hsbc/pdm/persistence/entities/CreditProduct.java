package com.hsbc.pdm.persistence.entities;


/**
 * @author kalakuriphani
 * @version 1.0
 * @created 10-Oct-2016 02:06:25
 */
public class CreditProduct {

	private Frequency frequency;
	private int id;
	private double maxLoanAmount;
	private double maxLoanDeposit;
	private int maxLoanTerm;
	private double minLoanAmount;
	private double minLoanDeposit;
	private int minLoanTerm;
	private double minMonthlyRepayment;
	private boolean paymentHolidayFlay;
	public Frequency m_Frequency;

	public CreditProduct(){

	}

	public void finalize() throws Throwable {

	}

	public Frequency getFrequency() {
		return frequency;
	}

	public void setFrequency(Frequency frequency) {
		this.frequency = frequency;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getMaxLoanAmount() {
		return maxLoanAmount;
	}

	public void setMaxLoanAmount(double maxLoanAmount) {
		this.maxLoanAmount = maxLoanAmount;
	}

	public double getMaxLoanDeposit() {
		return maxLoanDeposit;
	}

	public void setMaxLoanDeposit(double maxLoanDeposit) {
		this.maxLoanDeposit = maxLoanDeposit;
	}

	public int getMaxLoanTerm() {
		return maxLoanTerm;
	}

	public void setMaxLoanTerm(int maxLoanTerm) {
		this.maxLoanTerm = maxLoanTerm;
	}

	public double getMinLoanAmount() {
		return minLoanAmount;
	}

	public void setMinLoanAmount(double minLoanAmount) {
		this.minLoanAmount = minLoanAmount;
	}

	public double getMinLoanDeposit() {
		return minLoanDeposit;
	}

	public void setMinLoanDeposit(double minLoanDeposit) {
		this.minLoanDeposit = minLoanDeposit;
	}

	public int getMinLoanTerm() {
		return minLoanTerm;
	}

	public void setMinLoanTerm(int minLoanTerm) {
		this.minLoanTerm = minLoanTerm;
	}

	public double getMinMonthlyRepayment() {
		return minMonthlyRepayment;
	}

	public void setMinMonthlyRepayment(double minMonthlyRepayment) {
		this.minMonthlyRepayment = minMonthlyRepayment;
	}

	public boolean isPaymentHolidayFlay() {
		return paymentHolidayFlay;
	}

	public void setPaymentHolidayFlay(boolean paymentHolidayFlay) {
		this.paymentHolidayFlay = paymentHolidayFlay;
	}

	public Frequency getM_Frequency() {
		return m_Frequency;
	}

	public void setM_Frequency(Frequency m_Frequency) {
		this.m_Frequency = m_Frequency;
	}

}