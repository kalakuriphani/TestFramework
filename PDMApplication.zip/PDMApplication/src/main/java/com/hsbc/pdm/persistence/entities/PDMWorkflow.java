package com.hsbc.pdm.persistence.entities;

import java.util.Date;

import org.springframework.data.annotation.Id;

/**
 * @author kalakuriphani
 * @version 1.0
 * @created 10-Oct-2016 02:06:11
 */
public class PDMWorkflow {

	private String approvedBy;
	private Date approvedDate;
	private String approver;
	private String createdBy;
	private Date createdDate;
	@Id
	private int id;
	private String justification;
	private String lastModifiedBy;
	private Date lastModifiedDate;
	private Product product;
	private String Remarks;
	private Status status;
	private ProductType type;
	public ProductType m_ProductType;
	public Status m_Status;
	public Product m_Product;

	public PDMWorkflow(){

	}

	public void finalize() throws Throwable {

	}

	public String getApprovedBy() {
		return approvedBy;
	}

	public void setApprovedBy(String approvedBy) {
		this.approvedBy = approvedBy;
	}

	public Date getApprovedDate() {
		return approvedDate;
	}

	public void setApprovedDate(Date approvedDate) {
		this.approvedDate = approvedDate;
	}

	public String getApprover() {
		return approver;
	}

	public void setApprover(String approver) {
		this.approver = approver;
	}

	public String getCreatedBy() {
		return createdBy;
	}

	public void setCreatedBy(String createdBy) {
		this.createdBy = createdBy;
	}

	public Date getCreatedDate() {
		return createdDate;
	}

	public void setCreatedDate(Date createdDate) {
		this.createdDate = createdDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getJustification() {
		return justification;
	}

	public void setJustification(String justification) {
		this.justification = justification;
	}

	public String getLastModifiedBy() {
		return lastModifiedBy;
	}

	public void setLastModifiedBy(String lastModifiedBy) {
		this.lastModifiedBy = lastModifiedBy;
	}

	public Date getLastModifiedDate() {
		return lastModifiedDate;
	}

	public void setLastModifiedDate(Date lastModifiedDate) {
		this.lastModifiedDate = lastModifiedDate;
	}

	public Product getProduct() {
		return product;
	}

	public void setProduct(Product product) {
		this.product = product;
	}

	public String getRemarks() {
		return Remarks;
	}

	public void setRemarks(String remarks) {
		Remarks = remarks;
	}

	public Status getStatus() {
		return status;
	}

	public void setStatus(Status status) {
		this.status = status;
	}

	public ProductType getType() {
		return type;
	}

	public void setType(ProductType type) {
		this.type = type;
	}

	public ProductType getM_ProductType() {
		return m_ProductType;
	}

	public void setM_ProductType(ProductType m_ProductType) {
		this.m_ProductType = m_ProductType;
	}

	public Status getM_Status() {
		return m_Status;
	}

	public void setM_Status(Status m_Status) {
		this.m_Status = m_Status;
	}

	public Product getM_Product() {
		return m_Product;
	}

	public void setM_Product(Product m_Product) {
		this.m_Product = m_Product;
	}

}