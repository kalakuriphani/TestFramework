package com.hsbc.pdm.persistence.entities;

import java.util.List;

import org.springframework.data.annotation.Id;

/**
 * @author kalakuriphani
 * @version 1.0
 * @created 10-Oct-2016 02:06:30
 */
public class OverDraft {

	private List<Double> aodInterestTier;
	private double dailyCharge;
	@Id
	private int id;
	private double itemCharge;
	private double maxDailyODCharges;
	private double maxODAmount;
	private double maxUODAmount;
	private double monthlyCharge;
	private double otherCharge;
	private double uaDailyCharge;
	private double uaItemCharge;
	private double uaMonthlyCharge;
	private List<Double> uaodInterest;
	private double uaOtherCharge;

	public OverDraft(){

	}

	public void finalize() throws Throwable {

	}

	public List<Double> getAodInterestTier() {
		return aodInterestTier;
	}

	public void setAodInterestTier(List<Double> aodInterestTier) {
		this.aodInterestTier = aodInterestTier;
	}

	public double getDailyCharge() {
		return dailyCharge;
	}

	public void setDailyCharge(double dailyCharge) {
		this.dailyCharge = dailyCharge;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getItemCharge() {
		return itemCharge;
	}

	public void setItemCharge(double itemCharge) {
		this.itemCharge = itemCharge;
	}

	public double getMaxDailyODCharges() {
		return maxDailyODCharges;
	}

	public void setMaxDailyODCharges(double maxDailyODCharges) {
		this.maxDailyODCharges = maxDailyODCharges;
	}

	public double getMaxODAmount() {
		return maxODAmount;
	}

	public void setMaxODAmount(double maxODAmount) {
		this.maxODAmount = maxODAmount;
	}

	public double getMaxUODAmount() {
		return maxUODAmount;
	}

	public void setMaxUODAmount(double maxUODAmount) {
		this.maxUODAmount = maxUODAmount;
	}

	public double getMonthlyCharge() {
		return monthlyCharge;
	}

	public void setMonthlyCharge(double monthlyCharge) {
		this.monthlyCharge = monthlyCharge;
	}

	public double getOtherCharge() {
		return otherCharge;
	}

	public void setOtherCharge(double otherCharge) {
		this.otherCharge = otherCharge;
	}

	public double getUaDailyCharge() {
		return uaDailyCharge;
	}

	public void setUaDailyCharge(double uaDailyCharge) {
		this.uaDailyCharge = uaDailyCharge;
	}

	public double getUaItemCharge() {
		return uaItemCharge;
	}

	public void setUaItemCharge(double uaItemCharge) {
		this.uaItemCharge = uaItemCharge;
	}

	public double getUaMonthlyCharge() {
		return uaMonthlyCharge;
	}

	public void setUaMonthlyCharge(double uaMonthlyCharge) {
		this.uaMonthlyCharge = uaMonthlyCharge;
	}

	public List<Double> getUaodInterest() {
		return uaodInterest;
	}

	public void setUaodInterest(List<Double> uaodInterest) {
		this.uaodInterest = uaodInterest;
	}

	public double getUaOtherCharge() {
		return uaOtherCharge;
	}

	public void setUaOtherCharge(double uaOtherCharge) {
		this.uaOtherCharge = uaOtherCharge;
	}

}