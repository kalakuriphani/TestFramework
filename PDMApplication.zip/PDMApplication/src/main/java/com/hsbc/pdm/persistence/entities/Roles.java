package com.hsbc.pdm.persistence.entities;

import java.util.Set;

import org.springframework.data.annotation.Id;

/**
 * @author kalakuriphani
 * @version 1.0
 * @created 10-Oct-2016 02:06:32
 */
public class Roles {

	private Set<Access> access;
	@Id
	private int id;
	private String name;
	public Access m_Access;

	public Roles(){

	}

	public void finalize() throws Throwable {

	}

	public Set<Access> getAccess() {
		return access;
	}

	public void setAccess(Set<Access> access) {
		this.access = access;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Access getM_Access() {
		return m_Access;
	}

	public void setM_Access(Access m_Access) {
		this.m_Access = m_Access;
	}

}