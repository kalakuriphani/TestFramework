package com.hsbc.pdm.persistence.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.hsbc.pdm.persistence.entities.Access;

/**
 * @author kalakuriphani
 * @version 1.0
 * @created 10-Oct-2016 02:35:20
 */
public interface PermissionRepository extends MongoRepository<Access, Integer> {

	

}