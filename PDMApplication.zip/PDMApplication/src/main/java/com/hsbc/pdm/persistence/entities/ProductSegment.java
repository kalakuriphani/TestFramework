/**
 * 
 */
package com.hsbc.pdm.persistence.entities;

/**
 * @author kalakuriphani
 *
 */
public class ProductSegment {

}
