package com.hsbc.pdm.persistence.entities;


/**
 * @author kalakuriphani
 * @version 1.0
 * @created 10-Oct-2016 02:06:23
 */
public class Currency {

	public Currency(){

	}

	public void finalize() throws Throwable {

	}

}