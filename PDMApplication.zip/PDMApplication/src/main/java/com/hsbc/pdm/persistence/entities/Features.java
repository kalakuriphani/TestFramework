package com.hsbc.pdm.persistence.entities;

import org.springframework.data.annotation.Id;

/**
 * @author kalakuriphani
 * @version 1.0
 * @created 10-Oct-2016 02:06:27
 */
public class Features {

	private String feature;
	private boolean featureOptionalFlag;
	@Id
	private int id;
	private String notes;

	public Features(){

	}

	public void finalize() throws Throwable {

	}

	public String getFeature() {
		return feature;
	}

	public void setFeature(String feature) {
		this.feature = feature;
	}

	public boolean isFeatureOptionalFlag() {
		return featureOptionalFlag;
	}

	public void setFeatureOptionalFlag(boolean featureOptionalFlag) {
		this.featureOptionalFlag = featureOptionalFlag;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

}