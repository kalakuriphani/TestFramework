package com.hsbc.pdm.persistence.entities;


/**
 * @author kalakuriphani
 * @version 1.0
 * @created 10-Oct-2016 02:06:14
 */
public enum Status {
	New,
	PendingApproval,
	Reject,
	Approved,
	Active,
	InActive
}