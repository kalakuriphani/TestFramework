package com.hsbc.pdm.persistence.entities;

import java.util.Date;

/**
 * @author kalakuriphani
 * @version 1.0
 * @created 10-Oct-2016 02:06:24
 */
public class Availability {

	private Date fromDate;
	private int id;
	private Date toDate;

	public Availability(){

	}

	public void finalize() throws Throwable {

	}

	public Date getFromDate() {
		return fromDate;
	}

	public void setFromDate(Date fromDate) {
		this.fromDate = fromDate;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Date getToDate() {
		return toDate;
	}

	public void setToDate(Date toDate) {
		this.toDate = toDate;
	}

}