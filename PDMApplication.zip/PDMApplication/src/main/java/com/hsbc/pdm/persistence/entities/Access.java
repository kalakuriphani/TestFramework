package com.hsbc.pdm.persistence.entities;


/**
 * @author kalakuriphani
 * @version 1.0
 * @created 10-Oct-2016 02:06:35
 */
public class Access {

	private int accessType;
	private int id;
	private int page;

	public Access(){

	}

	public void finalize() throws Throwable {

	}

	public int getAccessType() {
		return accessType;
	}

	public void setAccessType(int accessType) {
		this.accessType = accessType;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getPage() {
		return page;
	}

	public void setPage(int page) {
		this.page = page;
	}

}