 package com.hsbc.pdm.persistence.repository;

import org.springframework.data.mongodb.repository.MongoRepository;

import com.hsbc.pdm.persistence.entities.Product;

/**
 * @author kalakuriphani
 * @version 1.0
 * @created 10-Oct-2016 02:35:19
 */
public interface ProductRepository extends MongoRepository<Product, Integer> {

	

}