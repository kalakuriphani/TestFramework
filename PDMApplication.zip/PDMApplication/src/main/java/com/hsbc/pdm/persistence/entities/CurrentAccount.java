package com.hsbc.pdm.persistence.entities;


/**
 * @author kalakuriphani
 * @version 1.0
 * @created 10-Oct-2016 02:06:36
 */
public class CurrentAccount {

	private int id;
	private double minMonthlyDeposit;
	private double minMonthlyFee;
	private boolean odAvailableFlag;
	private String odNote;
	private Criteria otherMonthlyCriteria;

	public CurrentAccount(){

	}

	public void finalize() throws Throwable {

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getMinMonthlyDeposit() {
		return minMonthlyDeposit;
	}

	public void setMinMonthlyDeposit(double minMonthlyDeposit) {
		this.minMonthlyDeposit = minMonthlyDeposit;
	}

	public double getMinMonthlyFee() {
		return minMonthlyFee;
	}

	public void setMinMonthlyFee(double minMonthlyFee) {
		this.minMonthlyFee = minMonthlyFee;
	}

	public boolean isOdAvailableFlag() {
		return odAvailableFlag;
	}

	public void setOdAvailableFlag(boolean odAvailableFlag) {
		this.odAvailableFlag = odAvailableFlag;
	}

	public String getOdNote() {
		return odNote;
	}

	public void setOdNote(String odNote) {
		this.odNote = odNote;
	}

	public Criteria getOtherMonthlyCriteria() {
		return otherMonthlyCriteria;
	}

	public void setOtherMonthlyCriteria(Criteria otherMonthlyCriteria) {
		this.otherMonthlyCriteria = otherMonthlyCriteria;
	}

}