package com.hsbc.pdm.persistence.entities;

import org.springframework.data.annotation.Id;

/**
 * @author kalakuriphani
 * @version 1.0
 * @created 10-Oct-2016 02:06:31
 */
public class SavingsProduct {

	@Id
	private int id;
	private Frequency ipFrequency;
	private double minOB;
	private int noOfWDallowed;
	private int noticeTerm;
	private int term;
	private String wdAllowedNotes;
	private boolean withdrawlAllowedFlag;
	private double withdrawlFee;

	public SavingsProduct(){

	}

	public void finalize() throws Throwable {

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public Frequency getIpFrequency() {
		return ipFrequency;
	}

	public void setIpFrequency(Frequency ipFrequency) {
		this.ipFrequency = ipFrequency;
	}

	public double getMinOB() {
		return minOB;
	}

	public void setMinOB(double minOB) {
		this.minOB = minOB;
	}

	public int getNoOfWDallowed() {
		return noOfWDallowed;
	}

	public void setNoOfWDallowed(int noOfWDallowed) {
		this.noOfWDallowed = noOfWDallowed;
	}

	public int getNoticeTerm() {
		return noticeTerm;
	}

	public void setNoticeTerm(int noticeTerm) {
		this.noticeTerm = noticeTerm;
	}

	public int getTerm() {
		return term;
	}

	public void setTerm(int term) {
		this.term = term;
	}

	public String getWdAllowedNotes() {
		return wdAllowedNotes;
	}

	public void setWdAllowedNotes(String wdAllowedNotes) {
		this.wdAllowedNotes = wdAllowedNotes;
	}

	public boolean isWithdrawlAllowedFlag() {
		return withdrawlAllowedFlag;
	}

	public void setWithdrawlAllowedFlag(boolean withdrawlAllowedFlag) {
		this.withdrawlAllowedFlag = withdrawlAllowedFlag;
	}

	public double getWithdrawlFee() {
		return withdrawlFee;
	}

	public void setWithdrawlFee(double withdrawlFee) {
		this.withdrawlFee = withdrawlFee;
	}

}