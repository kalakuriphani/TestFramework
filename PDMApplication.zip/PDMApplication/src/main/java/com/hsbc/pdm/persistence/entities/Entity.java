package com.hsbc.pdm.persistence.entities;

import java.util.Set;

import org.springframework.data.annotation.Id;

/**
 * @author kalakuriphani
 * @version 1.0
 * @created 10-Oct-2016 02:06:34
 */
public class Entity {
	@Id
	private int id;
	private String name;
	private Set<ProductType> productTypes;
	public ProductType m_ProductType;

	public Entity(){

	}

	public void finalize() throws Throwable {

	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Set<ProductType> getProductTypes() {
		return productTypes;
	}

	public void setProductTypes(Set<ProductType> productTypes) {
		this.productTypes = productTypes;
	}

	public ProductType getM_ProductType() {
		return m_ProductType;
	}

	public void setM_ProductType(ProductType m_ProductType) {
		this.m_ProductType = m_ProductType;
	}

}