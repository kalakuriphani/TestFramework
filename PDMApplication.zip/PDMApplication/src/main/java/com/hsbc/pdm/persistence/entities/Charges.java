package com.hsbc.pdm.persistence.entities;


/**
 * @author kalakuriphani
 * @version 1.0
 * @created 10-Oct-2016 02:06:25
 */
public class Charges {

	private String charges;
	private int id;
	private String notes;

	public Charges(){

	}

	public void finalize() throws Throwable {

	}

	public String getCharges() {
		return charges;
	}

	public void setCharges(String charges) {
		this.charges = charges;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getNotes() {
		return notes;
	}

	public void setNotes(String notes) {
		this.notes = notes;
	}

}